
package gerensystem;

import gerensystem.view.frmLogin;


public class Main {


    public static void main(String[] args) {
       frmLogin frm = new frmLogin();
       frm.show();
    }
    
}
