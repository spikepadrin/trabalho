
package gerensystem.model;


public class EntradaSaidaDTO {
    private int idProduto;
    private int idEstoque;
   private long codProd;
    private String marca;
    private String categoria;
    private String fornecedor;
    private float valorProd;
    private float valorVenda;
    private String validadeProd;
    private int estoqueAtual;
    private int estoqueAnterior;

    public int getIdProduto() {
        return idProduto;
    }

    public void setIdProduto(int idProduto) {
        this.idProduto = idProduto;
    }

    public int getIdEstoque() {
        return idEstoque;
    }

    public void setIdEstoque(int idEstoque) {
        this.idEstoque = idEstoque;
    }

    public long getCodProd() {
        return codProd;
    }

    public void setCodProd(long codProd) {
        this.codProd = codProd;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getFornecedor() {
        return fornecedor;
    }

    public void setFornecedor(String fornecedor) {
        this.fornecedor = fornecedor;
    }

    public float getValorProd() {
        return valorProd;
    }

    public void setValorProd(float valorProd) {
        this.valorProd = valorProd;
    }

    public float getValorVenda() {
        return valorVenda;
    }

    public void setValorVenda(float valorVenda) {
        this.valorVenda = valorVenda;
    }

    public String getValidadeProd() {
        return validadeProd;
    }

    public void setValidadeProd(String validadeProd) {
        this.validadeProd = validadeProd;
    }

    public int getEstoqueAtual() {
        return estoqueAtual;
    }

    public void setEstoqueAtual(int estoqueAtual) {
        this.estoqueAtual = estoqueAtual;
    }

    public int getEstoqueAnterior() {
        return estoqueAnterior;
    }

    public void setEstoqueAnterior(int estoqueAnterior) {
        this.estoqueAnterior = estoqueAnterior;
    }
    
    


}
