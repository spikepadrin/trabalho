
package gerensystem.model;
import java.util.ArrayList;

public class Produto {
    private int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    private long codProd;
    private String marca;
    private String categoria;
    private String fornecedor;
    private float valorProd;
    private float valorVenda;
    private String validadeProd;
    private int qtdeRecebida;
    private int qtdeMinEstoque;

    public long getCodProd() {
        return codProd;
    }

    public void setCodProd(long codProd) {
        this.codProd = codProd;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getFornecedor() {
        return fornecedor;
    }

    public void setFornecedor(String fornecedor) {
        this.fornecedor = fornecedor;
    }

    public float getValorProd() {
        return valorProd;
    }

    public void setValorProd(float valorProd) {
        this.valorProd = valorProd;
    }

    public float getValorVenda() {
        return valorVenda;
    }

    public void setValorVenda(float valorVenda) {
        this.valorVenda = valorVenda;
    }

    public String getValidadeProd() {
        return validadeProd;
    }

    public void setValidadeProd(String validadeProd) {
        this.validadeProd = validadeProd;
    }

    public int getQtdeRecebida() {
        return qtdeRecebida;
    }

    public void setQtdeRecebida(int qtdeRecebida) {
        this.qtdeRecebida = qtdeRecebida;
    }

    public int getQtdeMinEstoque() {
        return qtdeMinEstoque;
    }

    public void setQtdeMinEstoque(int qtdeMinEstoque) {
        this.qtdeMinEstoque = qtdeMinEstoque;
    }
    
    

    public void cadastrar() {
        // Implementação do método de cadastro
    }

    public void alterar() {
        // Implementação do método de alteração
    }

    public ArrayList listar() {
        // Implementação do método de listagem
        return new ArrayList();
    }

    public void buscar() {
        // Implementação do método de busca
    }
}
