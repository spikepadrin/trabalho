package gerensystem.DAO;

import gerensystem.conection.ModuloConexao;
import gerensystem.model.Funcionario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class FuncionarioDAO {

    private Connection connection = null;

    public FuncionarioDAO() {
        ModuloConexao c = new ModuloConexao();
        this.connection = c.retornaConexao();
    }

    public void adiciona(Funcionario funcionario) throws SQLException {
        PreparedStatement stmt = null;
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

        try {
            String sql = "INSERT INTO funcionarios (nome_completo, cpf, data_nasc, endereco, sexo, telefone, email, data_admissao, salario, cargo, funcao, login, senha) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            stmt = this.connection.prepareStatement(sql);

            stmt.setString(1, funcionario.getNomeCompleto());
            stmt.setString(2, funcionario.getCpf());

            try {
                // Corrigir a conversão de data
                java.util.Date dataNasc = sdf.parse(funcionario.getDataNasc());
                java.sql.Date sqlDataNasc = new java.sql.Date(dataNasc.getTime());
                stmt.setDate(3, sqlDataNasc);
            } catch (ParseException e) {
                e.printStackTrace();
                throw new SQLException("Erro ao converter data de nascimento", e);
            }

            stmt.setString(4, funcionario.getEndereco());
            stmt.setString(5, funcionario.getSexo());
            stmt.setString(6, funcionario.getTelefone());
            stmt.setString(7, funcionario.getEmail());

            try {
                // Corrigir a conversão de data
                java.util.Date dataAdmissao = sdf.parse(funcionario.getDataAdmissao());
                java.sql.Date sqlDataAdmissao = new java.sql.Date(dataAdmissao.getTime());
                stmt.setDate(8, sqlDataAdmissao);
            } catch (ParseException e) {
                e.printStackTrace();
                throw new SQLException("Erro ao converter data de admissão", e);
            }

            stmt.setFloat(9, funcionario.getSalario());
            stmt.setString(10, funcionario.getCargo());
            stmt.setString(11, funcionario.getFuncao());
            stmt.setString(12, funcionario.getLogin());
            stmt.setString(13, funcionario.getSenha());

            stmt.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (stmt != null) {
                stmt.close();
            }
        }
    }

    public ArrayList<Funcionario> retorna() throws SQLException {
        ArrayList<Funcionario> funcionarios = new ArrayList<Funcionario>();
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            String sql = "SELECT * FROM funcionarios";
            stmt = connection.prepareStatement(sql);
            rs = stmt.executeQuery();

            while (rs.next()) {
                Funcionario funcionario = new Funcionario();
                funcionario.setId(rs.getInt("id"));
                funcionario.setNomeCompleto(rs.getString("nome_completo"));
                funcionario.setCpf(rs.getString("cpf"));
                funcionario.setDataNasc(rs.getString("data_nasc"));
                funcionario.setEndereco(rs.getString("endereco"));
                funcionario.setSexo(rs.getString("sexo"));
                funcionario.setTelefone(rs.getString("telefone"));
                funcionario.setEmail(rs.getString("email"));
                funcionario.setDataAdmissao(rs.getString("data_admissao"));
                funcionario.setSalario(rs.getFloat("salario"));
                funcionario.setCargo(rs.getString("cargo"));
                funcionario.setFuncao(rs.getString("funcao"));
                funcionario.setLogin(rs.getString("login"));
                funcionario.setSenha(rs.getString("senha"));

                funcionarios.add(funcionario);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
        }

        return funcionarios;
    }
}
