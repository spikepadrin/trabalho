/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gerensystem.DAO;

import gerensystem.conection.ModuloConexao;
import gerensystem.model.EntradaSaidaDTO;
import gerensystem.model.Produto;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class ProdutoDAO {

    private Connection connection = null;
    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

    public ProdutoDAO() {
        ModuloConexao c = new ModuloConexao();
        this.connection = c.retornaConexao();
    }

    // Método para adicionar um produto ao banco de dados
public void adiciona(Produto produto) throws SQLException {
    PreparedStatement stmt = null;
    ResultSet generatedKeys = null;
    try {
        String sql = "INSERT INTO produtos (marca, "
                   + "categoria, fornecedor, valorProd, valorVenda, validadeProd, "
                   + "qtdeRecebida, qtdeMinEstoque) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        stmt = this.connection.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);

        stmt.setString(1, produto.getMarca());
        stmt.setString(2, produto.getCategoria());
        stmt.setString(3, produto.getFornecedor());
        stmt.setFloat(4, produto.getValorProd());
        stmt.setFloat(5, produto.getValorVenda());

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        try {
            java.util.Date dataValidade = sdf.parse(produto.getValidadeProd());
            java.sql.Date sqlData = new java.sql.Date(dataValidade.getTime());
            stmt.setDate(6, sqlData);
        } catch (ParseException e) {
            e.printStackTrace();
            throw new SQLException("Erro ao converter a data de validade", e);
        }

        stmt.setInt(7, produto.getQtdeRecebida());
        stmt.setInt(8, produto.getQtdeMinEstoque());

        stmt.executeUpdate();

        // Captura o ID gerado automaticamente
        generatedKeys = stmt.getGeneratedKeys();
        if (generatedKeys.next()) {
            int codProd = generatedKeys.getInt(1);
            produto.setCodProd(codProd);

            // Agora você pode usar o codProd para inserir dados em outra tabela
            inserirNaTabelaEstoque(codProd,produto.getQtdeRecebida());
        } else {
            throw new SQLException("A criação do produto falhou, nenhum ID obtido.");
        }
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        if (generatedKeys != null) {
            generatedKeys.close();
        }
        if (stmt != null) {
            stmt.close();
        }
    }
}

private void inserirNaTabelaEstoque(int codProd,int estoque) throws SQLException {
    PreparedStatement stmt = null;
    try {
        String sql = "INSERT INTO estoqueatual (idproduto, estoqueAtual, estoqueAnterior) VALUES (?, ?, ?)";
        stmt = this.connection.prepareStatement(sql);
        stmt.setInt(1, codProd);
        stmt.setInt(2, estoque);
        stmt.setInt(3, estoque);
        stmt.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        if (stmt != null) {
            stmt.close();
        }
    }
}

   
    // Método para listar todos os produtos do banco de dados
    public ArrayList<Produto> listar() throws SQLException {
        ArrayList<Produto> produtos = new ArrayList<Produto>();
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            String sql = "SELECT * FROM produtos";
            stmt = connection.prepareStatement(sql);
            rs = stmt.executeQuery();

            while (rs.next()) {
                Produto produto = new Produto();
                produto.setId(rs.getInt("id"));
                produto.setCodProd(rs.getLong("codProd"));
                produto.setMarca(rs.getString("marca"));
                produto.setCategoria(rs.getString("categoria"));
                produto.setFornecedor(rs.getString("fornecedor"));
                produto.setValorProd(rs.getFloat("valorProd"));
                produto.setValorVenda(rs.getFloat("valorVenda"));
                produto.setValidadeProd(rs.getDate("validadeProd").toString());
                produto.setQtdeRecebida(rs.getInt("qtdeRecebida"));
                produto.setQtdeMinEstoque(rs.getInt("qtdeMinEstoque"));

                produtos.add(produto);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
        }

        return produtos;
    }

    // Método para buscar um produto pelo código no banco de dados
    public Produto buscar(long codProd) throws SQLException {
        Produto produto = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            String sql = "SELECT * FROM produtos WHERE codProd = ?";
            stmt = connection.prepareStatement(sql);
            stmt.setLong(1, codProd);
            rs = stmt.executeQuery();

            if (rs.next()) {
                produto = new Produto();
                produto.setCodProd(rs.getLong("codProd"));
                produto.setMarca(rs.getString("marca"));
                produto.setCategoria(rs.getString("categoria"));
                produto.setFornecedor(rs.getString("fornecedor"));
                produto.setValorProd(rs.getFloat("valorProd"));
                produto.setValorVenda(rs.getFloat("valorVenda"));
                produto.setValidadeProd(rs.getDate("validadeProd").toString());
                produto.setQtdeRecebida(rs.getInt("qtdeRecebida"));
                produto.setQtdeMinEstoque(rs.getInt("qtdeMinEstoque"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
        }

        return produto;
    }
    
     // Método para listar todos os produtos do banco de dados
    public ArrayList<EntradaSaidaDTO> listarEstoques() throws SQLException {
        ArrayList<EntradaSaidaDTO> produtos = new ArrayList<EntradaSaidaDTO>();
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            String sql = "SELECT * FROM produtos inner join estoqueatual on produtos.id = estoqueatual.idproduto";
            stmt = connection.prepareStatement(sql);
            rs = stmt.executeQuery();

            while (rs.next()) {
                EntradaSaidaDTO produto = new EntradaSaidaDTO();
                produto.setIdProduto(rs.getInt("id"));
                produto.setCodProd(rs.getLong("codProd"));
                produto.setMarca(rs.getString("marca"));
                produto.setCategoria(rs.getString("categoria"));
                produto.setFornecedor(rs.getString("fornecedor"));
                produto.setValorProd(rs.getFloat("valorProd"));
                produto.setValorVenda(rs.getFloat("valorVenda"));
                produto.setValidadeProd(rs.getDate("validadeProd").toString());
                produto.setIdEstoque(rs.getInt("idestoqueatual"));
                produto.setEstoqueAtual(rs.getInt("estoqueAtual"));
                produto.setEstoqueAnterior(rs.getInt("estoqueAnterior"));


                produtos.add(produto);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
        }

        return produtos;
    }
    
     // Método para buscar um produto pelo ID
    public EntradaSaidaDTO buscarProdutoPorId(int id) throws SQLException {
        EntradaSaidaDTO produto = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            String sql = "SELECT * FROM produtos INNER JOIN estoqueatual ON produtos.id = estoqueatual.idproduto WHERE estoqueatual.idestoqueatual = ?";
            stmt = connection.prepareStatement(sql);
            stmt.setInt(1, id);
            rs = stmt.executeQuery();

            if (rs.next()) {
                produto = new EntradaSaidaDTO();
                produto.setIdProduto(rs.getInt("id"));
                produto.setCodProd(rs.getLong("codProd"));
                produto.setMarca(rs.getString("marca"));
                produto.setCategoria(rs.getString("categoria"));
                produto.setFornecedor(rs.getString("fornecedor"));
                produto.setValorProd(rs.getFloat("valorProd"));
                produto.setValorVenda(rs.getFloat("valorVenda"));
                produto.setValidadeProd(rs.getDate("validadeProd").toString());
                produto.setIdEstoque(rs.getInt("idestoqueatual"));
                produto.setEstoqueAtual(rs.getInt("estoqueAtual"));
                produto.setEstoqueAnterior(rs.getInt("estoqueAnterior"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
        }

        return produto;
    }
    
        public boolean atualizarEstoque(int idEstoque, int novoEstoque, int estoqueAnterior) throws SQLException {
        PreparedStatement stmt = null;
        try {
            String sql = "UPDATE estoqueatual SET estoqueAtual = ?,estoqueAnterior = ? WHERE idestoqueatual = ?";
            stmt = this.connection.prepareStatement(sql);
            stmt.setInt(1, novoEstoque);
            stmt.setInt(2, estoqueAnterior);
            stmt.setInt(3, idEstoque);
            

            int rowsUpdated = stmt.executeUpdate();
            return rowsUpdated > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            if (stmt != null) {
                stmt.close();
            }
        }
    }
}
