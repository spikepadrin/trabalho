
package gerensystem.view;

import gerensystem.DAO.ProdutoDAO;
import gerensystem.model.EntradaSaidaDTO;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.util.List;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;


public class frmSaida extends javax.swing.JFrame {


    public frmSaida() {
        initComponents();
        preencherTabela();
    }
    
      private void preencherTabela() {
        ProdutoDAO informacoesDAO = new ProdutoDAO();
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("idProduto");
        model.addColumn("idEstoque");
        model.addColumn("codProd");
        model.addColumn("marca");
        model.addColumn("categoria");
        model.addColumn("valorProd");
        model.addColumn("valorVenda");
        model.addColumn("validadeProd");
        model.addColumn("estoqueAtual");
        model.addColumn("estoqueAnterior");
        // Adicione mais colunas conforme necessário

        try {
            // Obtenha a lista de informações da escola do banco de dados
            List<EntradaSaidaDTO> informacoesList = informacoesDAO.listarEstoques();

            // Adicione os dados da lista ao modelo da tabela
            for (EntradaSaidaDTO informacoes : informacoesList) {
                model.addRow(new Object[]{
                        informacoes.getIdProduto(),
                        informacoes.getIdEstoque(),
                        informacoes.getCodProd(),                        
                        informacoes.getMarca(),
                        informacoes.getCategoria(),
                        informacoes.getFornecedor(),
                        informacoes.getValorProd(),
                        informacoes.getValorVenda(),
                        informacoes.getValidadeProd(),
                        informacoes.getEstoqueAtual(),
                        informacoes.getEstoqueAnterior()
                        // Adicione mais valores conforme necessário
                });
            }

            // Defina o modelo da tabela
            tblFuncionarios.setModel(model);
            
             tblFuncionarios.addMouseListener(new MouseAdapter() {
                public void mouseClicked(MouseEvent e) {
                    if (SwingUtilities.isRightMouseButton(e)) {
                        int row = tblFuncionarios.rowAtPoint(e.getPoint());
                        int col = 1; // Índice da terceira coluna (0-based index)

                        if (row != -1) {
                            Object value = tblFuncionarios.getValueAt(row, col);
                            System.out.println("Valor da terceira coluna da linha clicada: " + value);
                            frmConclusaoSaida saida = new frmConclusaoSaida((int) value);
                            dispose();
                            saida.show();
                        }
                    }
                }
            });


        } catch (SQLException e) {
            e.printStackTrace();
        }
    }



    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        tbl = new javax.swing.JScrollPane();
        tblFuncionarios = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        tblFuncionarios.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Title 1", "Title 2"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblFuncionarios.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        tbl.setViewportView(tblFuncionarios);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(tbl, javax.swing.GroupLayout.PREFERRED_SIZE, 729, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(tbl, javax.swing.GroupLayout.DEFAULT_SIZE, 310, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Saidas disponiveis", jPanel2);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 823, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents


    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmSaida.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmSaida.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmSaida.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmSaida.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmSaida().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel2;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JScrollPane tbl;
    private javax.swing.JTable tblFuncionarios;
    // End of variables declaration//GEN-END:variables
}
